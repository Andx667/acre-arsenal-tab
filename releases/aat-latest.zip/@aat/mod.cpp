name = "ACRE Arsenal Tab";
description = "ACRE Arsenal Tab";
tooltip = "ACRE Arsenal Tab";
overview = "This Mod adds a new Tab for ACRE Items to the ACE Arsenal right side.";
author = "Andx Arma Mods";